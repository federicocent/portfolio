var wow = new wow({
boxClass: 'wow',
animateClass: 'animated',
offset: 300,
mobile: true,
live: true,
callback: function(box) {
},
scrollContainer: null,
resetAnimation: true,
});
wow.init();